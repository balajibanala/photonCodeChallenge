# Raspberry PI Temperature and Humidity Sensor Integration Example with Thingworx

## Installation

This example can be run from your Raspberry PI or from any computer. It can also be run without the
AM2302 Humidity and Temperature Sensor (http://www.adafruit.com/products/393) temperature sensor since it
can generate simulated data.

It will require that you have access to a Thingworx server to push the data to which you can get from http://thingworx.com/
This example requires Apache Maven (http://maven.apache.org/) to build. Optionally, you can also work with it in any
ide that supports Maven.

### Installation on Your Raspberry PI

Install these packages on your PI before you begin.

sudo apt-get update
sudo apt-get install oracle-java7-jdk
sudo apt-get install maven

### Installation on other systems

Download an install java JDK7 at http://www.oracle.com/technetwork/java/javase/downloads/jdk7-downloads-1880260.html
Download and install Apache Maven at http://maven.apache.org/download.cgi

both maven and java should be added to your PATH environment variable (see http://www.computerhope.com/issues/ch000549.htm)
for help doing this.


### Building the example

To build the edge server jar on your PI or locally run this command from the project directory

`mvn package`

this will create the release jar in target/temperature-thing-jar-with-dependencies.jar

### Running the example

The following command will start your edge server from the target directory

On your PI
java -jar ./temperature-thing-jar-with-dependencies.jar <thingworx server url> <api key> <optional simulated>

On windows
java -jar temperature-thing-jar-with-dependencies.jar <thingworx server url> <api key> <optional simulated>

The parameters required to start the example will be different for everyone. This is how you determine them.

<thingworx server url> - If your thingworx server is on https://maker01.ptcmanaged.com/Thingworx for example then
your server URL will be wss://maker01.ptcmanaged.com:443/Thingworx/WS. If you are not using https then wss: should
be changed to just ws:

<api key> - An api key is a string that your edge client can use to log in as you without having your username or
password. You must log into Thingworx as you and generate one. From the home tab in the composer, find the section
called Application Keys and push the + button. Create a key called TemperatureThingKey and save it. Once saved copy
the generated key value and use it for this parameter.

<optional simulated> - If the third parameter is provided that is the word `simulated` then no hardware will be required
to run the example. It will use randomly generated temperature and humidity values.

Here is an example command:

`java -jar ./temperature-thing-jar-with-dependencies.jar wss://maker01.ptcmanaged.com:443/Thingworx/WS 7c73215e-ff40-47ee-9c18-d29a0c5310e0 simulated`

This will start the example using simulated data

### Deploying your example to a Raspberry PI

Once your jar is built, you can automatically deliver the resulting jar to your PI for testing. To do this you must copy the example maven settings
file from the conf/settings.xml directory into your home directory in the .m2 directory. Open and edit this file. Update it by putting your PI's log in username and
password in place of the sample.

Next edit the pom.xml file in this example's main directory. Under properties update the URL indicating where you want the jar to be copied to.


<properties>

	<!-- Replace raspberrypi with the hostname or ip address of your raspberry pi -->        
	<pi.deployment.url>scp://pi@raspberrypi/home/pi</pi.deployment.url> 
       
<properties>


Now from the command line run:

`mvn deploy`

This will deliver the jar to your PI automatically.

You can also run the example from maven if you update the other values in the properties section with the command:

`mvn exec:java`

