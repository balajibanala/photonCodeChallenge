package com.ptcmanaged.tempthing;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



/**
 * Author: wreichardt
 * Date: 6/12/14
 * Copyright PTC 2014
 */
public class Main extends BaseEdgeServer {
    private static final Logger LOG = LoggerFactory.getLogger(Main.class);
    public static final String THING_NAME = "Am2302Thing";
    public static final String THING_DESCRIPTION = "Sensor 2302";

    public static void main(String[] args) {
        try {

            parseArguments(args);
            client=getEdgeClient();
            client.bindThing(new TempAndHumidityThing(THING_NAME, THING_DESCRIPTION, client, simulated));
            LOG.debug("Connecting to " + address + " using key " + appKey);
            client.start();
            monitorThings();

        } catch (Exception e) {
            LOG.error("Server shutdown due to an exception.",e);
        }

    }


}
