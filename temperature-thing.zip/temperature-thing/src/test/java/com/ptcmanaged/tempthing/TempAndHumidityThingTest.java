package com.ptcmanaged.tempthing;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Author: wreichardt
 * Date: 7/30/14
 * Copyright PTC 2014
 */
public class TempAndHumidityThingTest {
    @Test
    public void testTempHumidityString(){
        String consoleValue="Temp=23.1*C  Humidity=50.7%";
        TempAndHumidityThing thThing = new TempAndHumidityThing("name", "description", null, "simulated");
        Double humidity = thThing.parseHumidityFromString(consoleValue);
        Double temperature = thThing.parseTemperatureFromString(consoleValue);
        assertEquals(new Double(23.1),temperature);
        assertEquals(new Double(50.7),humidity);
    }
}
